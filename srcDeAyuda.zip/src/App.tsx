import React, { useState, useEffect } from "react";
import Ajv from "ajv";  // Importa Ajv para la validación
import schema from "./plantas.schema.json";  // Importa el esquema JSON
import { plantas } from "./importarDatos";

// Crear una instancia de Ajv
const ajv = new Ajv();

// Compilar el esquema con Ajv
const validate = ajv.compile(schema);
const App = () => {
  const [validPlantas, setValidPlantas] = useState<any[]>([]); // Estado para almacenar plantas válidas

  useEffect(() => {
    // Validar los datos de las plantas
    const validPlantasData = plantas.filter((planta) => {
      const valid = validate(planta);  // Validar cada planta con el esquema
      if (valid) {
          console.log("Esta Planta pasa de ronda:", planta);  // Mostrar mensaje de éxito en la consola
        return true;  // Planta válida
      } else {
        console.error("Planta no válida:", planta, validate.errors);  // Planta no válida, mostrar error en consola
        return false;
      }
    });

    setValidPlantas(validPlantasData);  // Actualizar el estado con las plantas válidas
  }, []);

  return (
    <div className="contenedor">
      {validPlantas.map((planta) => (
        <div className="cuadro" key={planta.especie_id}>
          <h2>{planta.nom_cas}</h2>
          <h3>{planta.especie_id}</h3>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBs1gOQynrLXGofj98YaLUKSnh4P0OSA1Yag&s" alt={planta.nom_cas} />
          <p>{planta.nom_ctf}</p>
        </div>
      ))}
    </div>
  );
};

export default App;


// Link de donde saco la lista JSON
// https://opendata-ajuntament.barcelona.cat/data/ca/dataset/atles-biodiversitat-flora-especies