import plantica from "./dades.json"

// Definir el tipo Planta
export type Planta = {
  especie_id: string;
  nom_ctf: string;
  nom_cat: string;
  nom_cas: string;
  nom_eng: string;
  desc_cat: string;
  desc_cas: string;
  desc_eng: string;
};

// Exportar los datos del JSON
export const plantas : Planta[] = plantica;
export const nombre_cast: string[] = plantica.map((p: Planta) => p.desc_cas);
export const especie_id: string[] = plantica.map((p: Planta) => p.especie_id);

