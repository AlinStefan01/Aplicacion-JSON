import miavatar from "./dades.json"

// Definir el tipo Avatar
export type Avatar = {
  name: string;
  power: number;
  alien: boolean;
};

// Exportar los datos del JSON tipados
export const user : Avatar[] = miavatar;
export const fuerza: Avatar[]=[];
for (const i of user){
  if (i.power > 50)
    fuerza.push(i)
}

console.log(user)