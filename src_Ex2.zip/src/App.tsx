import {fuerza, user, Avatar } from "./importarDatos.ts";
export default function App() {
  
 
   
  return (
    <div className="container">
      {fuerza.map((user) => (
        <div  className="ficha" style={{ backgroundColor: user.alien ? 'lightgreen' : 'lightblue' }}>
          <img src="public\zamn.png" width="100%"></img>
          <h3>{user.name}</h3>
          <p><strong>Power:</strong> {user.power}</p>
          <p><strong>Alien:</strong> {user.alien ? "Sí" : "No"}</p>
        </div>
      ))}
    </div>
  )
}
